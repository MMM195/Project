function adminFormatPrice(n) {
  return '฿' + Number(n).toLocaleString('th-TH');
}

function adminFormatDate(d) {
  return new Date(d).toLocaleDateString('th-TH', { year: 'numeric', month: 'short', day: 'numeric' });
}

function adminCalcNights(checkIn, checkOut) {
  const [inY, inM, inD] = checkIn.split('-').map(Number);
  const [outY, outM, outD] = checkOut.split('-').map(Number);
  const inUTC = Date.UTC(inY, inM - 1, inD);
  const outUTC = Date.UTC(outY, outM - 1, outD);
  return Math.round((outUTC - inUTC) / (1000 * 60 * 60 * 24));
}

function adminStatusLabel(status) {
  if (status === 'confirmed') return { text: 'ยืนยันแล้ว', cls: 'is-confirmed' };
  if (status === 'cancelled') return { text: 'ยกเลิกแล้ว', cls: 'is-cancelled' };
  return { text: 'รอยืนยัน', cls: 'is-pending' };
}

let currentStatus = 'pending';

function renderLoginPrompt() {
  document.getElementById('adminContent').innerHTML = `
    <div class="detail-error">
      <h2>กรุณาเข้าสู่ระบบ</h2>
      <p>เข้าสู่ระบบด้วยบัญชีแอดมินเพื่อจัดการการจอง</p>
      <button type="button" class="search-btn" id="goLoginBtn">เข้าสู่ระบบ</button>
    </div>
  `;
  const btn = document.getElementById('goLoginBtn');
  if (btn) btn.addEventListener('click', () => openAuthModal('login'));
}

function renderNotAdmin() {
  document.getElementById('adminContent').innerHTML = `
    <div class="detail-error">
      <h2>ไม่มีสิทธิ์เข้าถึงส่วนนี้</h2>
      <p>บัญชีของคุณไม่ใช่แอดมิน กรุณาติดต่อผู้ดูแลระบบหากคิดว่านี่เป็นข้อผิดพลาด</p>
      <a href="index.html" class="search-btn">กลับหน้าแรก</a>
    </div>
  `;
  document.getElementById('adminTabs').style.display = 'none';
}

function renderEmpty() {
  document.getElementById('adminContent').innerHTML = `
    <div class="detail-error">
      <h2>ไม่มีรายการในหมวดนี้</h2>
      <p>ลองเปลี่ยนไปดูแท็บอื่น</p>
    </div>
  `;
}

function renderAdminBookings(bookings) {
  const el = document.getElementById('adminContent');
  el.innerHTML = `
    <div class="bookings-list">
      ${bookings.map(b => {
        const room = b.room || {};
        const user = b.user || {};
        const st = adminStatusLabel(b.status);
        const nights = adminCalcNights(b.check_in, b.check_out);
        let actions = '';
        if (b.status === 'pending') {
          actions = `
            <div class="admin-actions">
              <button type="button" class="confirm-btn" data-id="${b.id}" data-status="confirmed">ยืนยันรับลูกค้า</button>
              <button type="button" class="cancel-btn" data-id="${b.id}" data-status="cancelled">ปฏิเสธ</button>
            </div>
          `;
        } else if (b.status === 'confirmed') {
          actions = `
            <div class="admin-actions">
              <button type="button" class="cancel-btn" data-id="${b.id}" data-status="cancelled">ยกเลิกการจอง</button>
            </div>
          `;
        }
        return `
          <div class="booking-card-item admin-item">
            <div class="booking-card-main">
              <p class="admin-user">${user.name || ''} <span>· ${user.email || ''}</span></p>
              <span class="room-num" style="color:var(--clay);">${room.number || ''} · ${room.category_label || ''}</span>
              <h3>${room.name || 'ห้องพัก'}</h3>
              <p class="booking-dates">${adminFormatDate(b.check_in)} — ${adminFormatDate(b.check_out)} (${nights} คืน)</p>
              <p class="booking-meta">${b.rooms_count || 1} ห้อง · ${b.adults} ผู้เข้าพัก · จองเมื่อ ${adminFormatDate(b.created_at)}</p>
            </div>
            <div class="booking-card-side">
              <span class="booking-status ${st.cls}">${st.text}</span>
              <span class="booking-price">${adminFormatPrice(b.total_price || 0)}</span>
              ${actions}
            </div>
          </div>
        `;
      }).join('')}
    </div>
  `;

  el.querySelectorAll('.confirm-btn, .cancel-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const newStatus = btn.dataset.status;
      const id = btn.dataset.id;
      const group = btn.closest('.admin-actions');
      group.querySelectorAll('button').forEach(b => b.disabled = true);
      btn.textContent = 'กำลังอัปเดต…';

      const res = await fetch(`${API_BASE}/update-booking-status.php`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status: newStatus })
      });
      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        alert('อัปเดตไม่สำเร็จ: ' + (data.error || ''));
        group.querySelectorAll('button').forEach(b => b.disabled = false);
        loadAdminBookings();
        return;
      }
      loadAdminBookings();
    });
  });
}

async function loadAdminBookings() {
  const el = document.getElementById('adminContent');
  el.innerHTML = '<p class="detail-loading">กำลังโหลดรายการจอง…</p>';

  const query = currentStatus ? `?status=${encodeURIComponent(currentStatus)}` : '';
  const res = await fetch(`${API_BASE}/admin-bookings.php${query}`, { credentials: 'include' });

  if (res.status === 401) {
    renderLoginPrompt();
    return;
  }
  if (res.status === 403) {
    renderNotAdmin();
    return;
  }
  if (!res.ok) {
    el.innerHTML = `<p class="detail-loading">ไม่สามารถโหลดรายการจองได้ในขณะนี้</p>`;
    return;
  }

  const data = await res.json();
  if (!data || data.length === 0) {
    renderEmpty();
    return;
  }
  renderAdminBookings(data);
}

document.querySelectorAll('.admin-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.admin-tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    currentStatus = tab.dataset.status;
    loadAdminBookings();
  });
});

async function initAdminPage() {
  const user = await getCurrentUser();
  if (!user) {
    renderLoginPrompt();
    return;
  }
  if (!user.is_admin) {
    renderNotAdmin();
    return;
  }
  loadAdminBookings();
}

initAdminPage();
// รีโหลดอัตโนมัติเมื่อสถานะล็อกอินเปลี่ยน (เช่น ล็อกอินสำเร็จผ่าน modal)
window.addEventListener('authchange', initAdminPage);
