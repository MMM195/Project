<?php
require __DIR__ . '/db.php';

if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'กรุณาเข้าสู่ระบบ']);
    exit;
}

$meStmt = $pdo->prepare('SELECT is_admin FROM users WHERE id = ?');
$meStmt->execute([$_SESSION['user_id']]);
$me = $meStmt->fetch();

if (!$me || !$me['is_admin']) {
    http_response_code(403);
    echo json_encode(['error' => 'ไม่มีสิทธิ์เข้าถึงส่วนนี้']);
    exit;
}

$input  = json_decode(file_get_contents('php://input'), true) ?? [];
$id     = $input['id'] ?? null;
$status = $input['status'] ?? null;

$allowed = ['pending', 'confirmed', 'cancelled'];
if (!$id || !in_array($status, $allowed, true)) {
    http_response_code(400);
    echo json_encode(['error' => 'ข้อมูลไม่ถูกต้อง']);
    exit;
}

$check = $pdo->prepare('SELECT id FROM bookings WHERE id = ?');
$check->execute([$id]);
if (!$check->fetch()) {
    http_response_code(404);
    echo json_encode(['error' => 'ไม่พบรายการจองนี้']);
    exit;
}

$stmt = $pdo->prepare('UPDATE bookings SET status = ? WHERE id = ?');
$stmt->execute([$status, $id]);

echo json_encode(['ok' => true]);
