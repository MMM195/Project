<?php
require __DIR__ . '/db.php';

$stmt = $pdo->query('
    SELECT r.id, r.content, r.created_at, u.full_name
    FROM reviews r
    JOIN users u ON u.id = r.user_id
    ORDER BY r.created_at DESC
    LIMIT 30
');
$rows = $stmt->fetchAll();

echo json_encode($rows);
