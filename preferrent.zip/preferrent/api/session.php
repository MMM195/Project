<?php
require __DIR__ . '/db.php';

if (empty($_SESSION['user_id'])) {
    echo json_encode(['user' => null]);
    exit;
}

$stmt = $pdo->prepare('SELECT id, full_name, email, is_admin FROM users WHERE id = ?');
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if ($user) {
    $user['is_admin'] = (bool) $user['is_admin'];
}

echo json_encode(['user' => $user ?: null]);