<?php
require __DIR__ . '/db.php';

if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'กรุณาเข้าสู่ระบบก่อนทำการจอง']);
    exit;
}

$input      = json_decode(file_get_contents('php://input'), true) ?? [];
$roomId     = $input['room_id'] ?? null;
$checkIn    = $input['check_in'] ?? null;
$checkOut   = $input['check_out'] ?? null;
$roomsCount = max(1, (int) ($input['rooms_count'] ?? 1));
$adults     = max(1, (int) ($input['adults'] ?? 1));

if (!$roomId || !$checkIn || !$checkOut) {
    http_response_code(400);
    echo json_encode(['error' => 'ข้อมูลการจองไม่ครบถ้วน']);
    exit;
}

$nights = (strtotime($checkOut) - strtotime($checkIn)) / 86400;
if ($nights <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'วันออกต้องหลังวันเข้าพัก']);
    exit;
}

$stmt = $pdo->prepare('SELECT * FROM rooms WHERE id = ?');
$stmt->execute([$roomId]);
$room = $stmt->fetch();

if (!$room) {
    http_response_code(404);
    echo json_encode(['error' => 'ไม่พบห้องพักนี้']);
    exit;
}

// คำนวณราคารวมฝั่งเซิร์ฟเวอร์เสมอ ป้องกันการปลอมแปลงราคาจากฝั่งเว็บ
$totalPrice = $room['price'] * $roomsCount * $nights;

$insert = $pdo->prepare('
    INSERT INTO bookings (user_id, room_id, check_in, check_out, rooms_count, adults, total_price, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, "pending")
');
$insert->execute([$_SESSION['user_id'], $roomId, $checkIn, $checkOut, $roomsCount, $adults, $totalPrice]);

echo json_encode([
    'id'          => (int) $pdo->lastInsertId(),
    'total_price' => (float) $totalPrice,
    'nights'      => (int) $nights,
]);
