<?php
require __DIR__ . '/db.php';

$id = $_GET['id'] ?? null;
if (!$id) {
    http_response_code(400);
    echo json_encode(['error' => 'ไม่พบรหัสห้องพัก']);
    exit;
}

$stmt = $pdo->prepare('SELECT * FROM rooms WHERE id = ?');
$stmt->execute([$id]);
$room = $stmt->fetch();

if (!$room) {
    http_response_code(404);
    echo json_encode(['error' => 'ไม่พบห้องพักนี้']);
    exit;
}

$room['available'] = (bool) $room['available'];
$room['price']      = (float) $room['price'];
$room['capacity']   = (int) $room['capacity'];
$room['beds']       = (int) ($room['beds'] ?? 1);
$room['quantity']   = $room['quantity'] !== null ? (int) $room['quantity'] : null;

echo json_encode($room);
