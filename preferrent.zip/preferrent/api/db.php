<?php
// ตั้งค่าการเชื่อมต่อฐานข้อมูล MySQL — แก้ 4 ค่านี้ให้ตรงกับของจริงบนโฮสต์/phpMyAdmin ของคุณ
$DB_HOST = 'localhost';
$DB_NAME = 'preferrent';
$DB_USER = 'root';
$DB_PASS = '';

try {
    $pdo = new PDO(
        "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => 'เชื่อมต่อฐานข้อมูลไม่สำเร็จ']);
    exit;
}

// session เดียวกันสำหรับทุก endpoint (ใช้แทน Supabase Auth)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json; charset=utf-8');
