<?php
require __DIR__ . '/db.php';

if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'กรุณาเข้าสู่ระบบ']);
    exit;
}

$meStmt = $pdo->prepare('SELECT is_admin FROM users WHERE id = ?');
$meStmt->execute([$_SESSION['user_id']]);
$me = $meStmt->fetch();

if (!$me || !$me['is_admin']) {
    http_response_code(403);
    echo json_encode(['error' => 'ไม่มีสิทธิ์เข้าถึงส่วนนี้']);
    exit;
}

$status  = $_GET['status'] ?? null;
$allowed = ['pending', 'confirmed', 'cancelled'];

$sql = '
    SELECT b.*, r.name AS room_name, r.number AS room_number,
           r.category_label AS room_category_label,
           u.full_name AS user_name, u.email AS user_email
    FROM bookings b
    JOIN rooms r ON r.id = b.room_id
    JOIN users u ON u.id = b.user_id
';
$params = [];

if ($status && in_array($status, $allowed, true)) {
    $sql .= ' WHERE b.status = ?';
    $params[] = $status;
}

$sql .= ' ORDER BY b.created_at DESC';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$result = array_map(function ($row) {
    return [
        'id'          => (int) $row['id'],
        'check_in'    => $row['check_in'],
        'check_out'   => $row['check_out'],
        'rooms_count' => (int) $row['rooms_count'],
        'adults'      => (int) $row['adults'],
        'total_price' => (float) $row['total_price'],
        'status'      => $row['status'],
        'created_at'  => $row['created_at'],
        'user' => [
            'name'  => $row['user_name'],
            'email' => $row['user_email'],
        ],
        'room' => [
            'name'           => $row['room_name'],
            'number'         => $row['room_number'],
            'category_label' => $row['room_category_label'],
        ],
    ];
}, $rows);

echo json_encode($result);
