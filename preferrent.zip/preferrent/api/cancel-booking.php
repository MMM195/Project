<?php
require __DIR__ . '/db.php';

if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'กรุณาเข้าสู่ระบบ']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true) ?? [];
$id    = $input['id'] ?? null;

if (!$id) {
    http_response_code(400);
    echo json_encode(['error' => 'ไม่พบรหัสการจอง']);
    exit;
}

$stmt = $pdo->prepare('UPDATE bookings SET status = "cancelled" WHERE id = ? AND user_id = ?');
$stmt->execute([$id, $_SESSION['user_id']]);

if ($stmt->rowCount() === 0) {
    http_response_code(404);
    echo json_encode(['error' => 'ไม่พบรายการจองนี้ หรือคุณไม่มีสิทธิ์ยกเลิก']);
    exit;
}

echo json_encode(['ok' => true]);
