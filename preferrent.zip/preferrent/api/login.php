<?php
require __DIR__ . '/db.php';

$input    = json_decode(file_get_contents('php://input'), true) ?? [];
$email    = trim($input['email'] ?? '');
$password = $input['password'] ?? '';

$stmt = $pdo->prepare('SELECT id, full_name, email, password_hash, is_admin FROM users WHERE email = ?');
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password_hash'])) {
    http_response_code(401);
    echo json_encode(['error' => 'อีเมลหรือรหัสผ่านไม่ถูกต้อง']);
    exit;
}

$_SESSION['user_id'] = (int) $user['id'];

echo json_encode([
    'id'        => (int) $user['id'],
    'full_name' => $user['full_name'],
    'email'     => $user['email'],
    'is_admin'  => (bool) $user['is_admin'],
]);