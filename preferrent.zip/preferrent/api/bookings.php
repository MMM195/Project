<?php
require __DIR__ . '/db.php';

if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'กรุณาเข้าสู่ระบบ']);
    exit;
}

$stmt = $pdo->prepare('
    SELECT b.*, r.name AS room_name, r.number AS room_number,
           r.category_label AS room_category_label, r.price AS room_price
    FROM bookings b
    JOIN rooms r ON r.id = b.room_id
    WHERE b.user_id = ?
    ORDER BY b.created_at DESC
');
$stmt->execute([$_SESSION['user_id']]);
$rows = $stmt->fetchAll();

$result = array_map(function ($row) {
    return [
        'id'          => (int) $row['id'],
        'check_in'    => $row['check_in'],
        'check_out'   => $row['check_out'],
        'rooms_count' => (int) $row['rooms_count'],
        'adults'      => (int) $row['adults'],
        'total_price' => (float) $row['total_price'],
        'status'      => $row['status'],
        'created_at'  => $row['created_at'],
        'room' => [
            'name'           => $row['room_name'],
            'number'         => $row['room_number'],
            'category_label' => $row['room_category_label'],
            'price'          => (float) $row['room_price'],
        ],
    ];
}, $rows);

echo json_encode($result);
