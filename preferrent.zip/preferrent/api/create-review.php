<?php
require __DIR__ . '/db.php';

if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'กรุณาเข้าสู่ระบบก่อนเขียนรีวิว']);
    exit;
}

$input   = json_decode(file_get_contents('php://input'), true) ?? [];
$content = trim($input['content'] ?? '');

if ($content === '') {
    http_response_code(400);
    echo json_encode(['error' => 'กรุณากรอกข้อความรีวิว']);
    exit;
}
if (mb_strlen($content) > 500) {
    http_response_code(400);
    echo json_encode(['error' => 'รีวิวยาวเกินไป (ไม่เกิน 500 ตัวอักษร)']);
    exit;
}

$stmt = $pdo->prepare('INSERT INTO reviews (user_id, content) VALUES (?, ?)');
$stmt->execute([$_SESSION['user_id'], $content]);

echo json_encode(['id' => (int) $pdo->lastInsertId()]);
