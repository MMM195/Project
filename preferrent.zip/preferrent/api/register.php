<?php
require __DIR__ . '/db.php';

$input = json_decode(file_get_contents('php://input'), true) ?? [];
$fullName = trim($input['full_name'] ?? '');
$email    = trim($input['email'] ?? '');
$password = $input['password'] ?? '';

if ($fullName === '' || $email === '' || strlen($password) < 6) {
    http_response_code(400);
    echo json_encode(['error' => 'กรุณากรอกข้อมูลให้ครบถ้วน (รหัสผ่านอย่างน้อย 6 ตัวอักษร)']);
    exit;
}

$check = $pdo->prepare('SELECT id FROM users WHERE email = ?');
$check->execute([$email]);
if ($check->fetch()) {
    http_response_code(409);
    echo json_encode(['error' => 'อีเมลนี้ถูกใช้สมัครแล้ว']);
    exit;
}

$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = $pdo->prepare('INSERT INTO users (full_name, email, password_hash) VALUES (?, ?, ?)');
$stmt->execute([$fullName, $email, $hash]);

$userId = (int) $pdo->lastInsertId();
$_SESSION['user_id'] = $userId;

echo json_encode(['id' => $userId, 'full_name' => $fullName, 'email' => $email]);
