<?php
require __DIR__ . '/db.php';

$stmt = $pdo->query('SELECT * FROM rooms ORDER BY number ASC');
$rooms = $stmt->fetchAll();

foreach ($rooms as &$r) {
    $r['available'] = (bool) $r['available'];
    $r['price']      = (float) $r['price'];
    $r['capacity']   = (int) $r['capacity'];
    $r['beds']       = (int) ($r['beds'] ?? 1);
    $r['quantity']   = $r['quantity'] !== null ? (int) $r['quantity'] : null;
}
unset($r);

echo json_encode($rooms);
