-- =========================================================
-- PreferRent — MySQL schema + ข้อมูลห้องพักเริ่มต้น (สำหรับ phpMyAdmin)
-- นำเข้าไฟล์นี้ใน phpMyAdmin: เลือกฐานข้อมูล > แท็บ Import > เลือกไฟล์นี้
-- =========================================================

CREATE TABLE IF NOT EXISTS users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  full_name     VARCHAR(150)  NOT NULL,
  email         VARCHAR(190)  NOT NULL UNIQUE,
  password_hash VARCHAR(255)  NOT NULL,
  created_at    DATETIME      DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS rooms (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  name            VARCHAR(150)   NOT NULL,
  number          VARCHAR(20)    NOT NULL,
  category        VARCHAR(50)    NOT NULL,          -- 'วิวเมือง' หรือ 'ริมแม่น้ำ' (ใช้กรองในหน้าเว็บ)
  category_label  VARCHAR(120)   NOT NULL,           -- ข้อความแสดงคู่กับเลขห้อง
  price           DECIMAL(10,2)  NOT NULL,
  capacity        INT            NOT NULL DEFAULT 2,
  quantity        INT            DEFAULT NULL,       -- NULL = ห้องเดี่ยว ไม่มีห้องย่อยหลายห้อง
  description     TEXT,
  image           VARCHAR(255)   DEFAULT NULL,
  scene_class     VARCHAR(50)    DEFAULT NULL,       -- ใช้กับ CSS พื้นหลังตอนยังไม่มีรูปจริง
  available       TINYINT(1)     NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS bookings (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  user_id      INT NOT NULL,
  room_id      INT NOT NULL,
  check_in     DATE NOT NULL,
  check_out    DATE NOT NULL,
  rooms_count  INT NOT NULL DEFAULT 1,
  adults       INT NOT NULL DEFAULT 1,
  total_price  DECIMAL(10,2) NOT NULL,
  status       ENUM('pending','confirmed','cancelled') NOT NULL DEFAULT 'pending',
  created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =========================================================
-- ข้อมูลห้องพัก PreferRent — รวม 12 ห้อง
-- เตียงคู่(ควีน)/เตียงเดี่ยว(คิง) x วิวเมือง/ริมแม่น้ำ อย่างละ 3 ห้อง
-- =========================================================
INSERT INTO rooms (name, number, category, category_label, price, capacity, quantity, description, scene_class, available) VALUES
('ห้องเตียงคู่ วิวเมือง',   '101', 'วิวเมือง',   'เตียงคู่ (ควีน) · วิวเมือง',   1800.00, 2, NULL, 'ห้องเตียงควีนไซส์ 2 เตียง มองเห็นวิวเส้นขอบฟ้าเมือง เหมาะสำหรับเพื่อนหรือครอบครัว', 'scene-city',  1),
('ห้องเตียงคู่ วิวเมือง',   '102', 'วิวเมือง',   'เตียงคู่ (ควีน) · วิวเมือง',   1800.00, 2, NULL, 'ห้องเตียงควีนไซส์ 2 เตียง มองเห็นวิวเส้นขอบฟ้าเมือง เหมาะสำหรับเพื่อนหรือครอบครัว', 'scene-city',  1),
('ห้องเตียงคู่ วิวเมือง',   '103', 'วิวเมือง',   'เตียงคู่ (ควีน) · วิวเมือง',   1800.00, 2, NULL, 'ห้องเตียงควีนไซส์ 2 เตียง มองเห็นวิวเส้นขอบฟ้าเมือง เหมาะสำหรับเพื่อนหรือครอบครัว', 'scene-city',  1),

('ห้องเตียงเดี่ยว วิวเมือง', '104', 'วิวเมือง',  'เตียงเดี่ยว (คิง) · วิวเมือง', 2000.00, 2, NULL, 'ห้องเตียงคิงไซส์ 1 เตียง มองเห็นวิวเมืองยามค่ำคืน บรรยากาศเงียบสงบส่วนตัว', 'scene-city',  1),
('ห้องเตียงเดี่ยว วิวเมือง', '105', 'วิวเมือง',  'เตียงเดี่ยว (คิง) · วิวเมือง', 2000.00, 2, NULL, 'ห้องเตียงคิงไซส์ 1 เตียง มองเห็นวิวเมืองยามค่ำคืน บรรยากาศเงียบสงบส่วนตัว', 'scene-city',  1),
('ห้องเตียงเดี่ยว วิวเมือง', '106', 'วิวเมือง',  'เตียงเดี่ยว (คิง) · วิวเมือง', 2000.00, 2, NULL, 'ห้องเตียงคิงไซส์ 1 เตียง มองเห็นวิวเมืองยามค่ำคืน บรรยากาศเงียบสงบส่วนตัว', 'scene-city',  1),

('ห้องเตียงคู่ ริมแม่น้ำ',   '201', 'ริมแม่น้ำ',  'เตียงคู่ (ควีน) · ริมแม่น้ำ',  2400.00, 2, NULL, 'ห้องเตียงควีนไซส์ 2 เตียง พร้อมระเบียงส่วนตัวริมแม่น้ำเจ้าพระยา', 'scene-river', 1),
('ห้องเตียงคู่ ริมแม่น้ำ',   '202', 'ริมแม่น้ำ',  'เตียงคู่ (ควีน) · ริมแม่น้ำ',  2400.00, 2, NULL, 'ห้องเตียงควีนไซส์ 2 เตียง พร้อมระเบียงส่วนตัวริมแม่น้ำเจ้าพระยา', 'scene-river', 1),
('ห้องเตียงคู่ ริมแม่น้ำ',   '203', 'ริมแม่น้ำ',  'เตียงคู่ (ควีน) · ริมแม่น้ำ',  2400.00, 2, NULL, 'ห้องเตียงควีนไซส์ 2 เตียง พร้อมระเบียงส่วนตัวริมแม่น้ำเจ้าพระยา', 'scene-river', 1),

('ห้องเตียงเดี่ยว ริมแม่น้ำ', '204', 'ริมแม่น้ำ', 'เตียงเดี่ยว (คิง) · ริมแม่น้ำ', 2700.00, 2, NULL, 'ห้องเตียงคิงไซส์ 1 เตียง พร้อมระเบียงส่วนตัวชมพระอาทิตย์ตกริมแม่น้ำเจ้าพระยา', 'scene-river', 1),
('ห้องเตียงเดี่ยว ริมแม่น้ำ', '205', 'ริมแม่น้ำ', 'เตียงเดี่ยว (คิง) · ริมแม่น้ำ', 2700.00, 2, NULL, 'ห้องเตียงคิงไซส์ 1 เตียง พร้อมระเบียงส่วนตัวชมพระอาทิตย์ตกริมแม่น้ำเจ้าพระยา', 'scene-river', 1),
('ห้องเตียงเดี่ยว ริมแม่น้ำ', '206', 'ริมแม่น้ำ', 'เตียงเดี่ยว (คิง) · ริมแม่น้ำ', 2700.00, 2, NULL, 'ห้องเตียงคิงไซส์ 1 เตียง พร้อมระเบียงส่วนตัวชมพระอาทิตย์ตกริมแม่น้ำเจ้าพระยา', 'scene-river', 1);

-- =========================================================
-- Migration: เพิ่มคอลัมน์ beds (จำนวนเตียงในห้อง) สำหรับใช้กรองค้นหา
-- รันส่วนนี้ถ้าฐานข้อมูลถูกสร้างไปแล้วก่อนหน้านี้
-- =========================================================
ALTER TABLE rooms ADD COLUMN beds TINYINT NOT NULL DEFAULT 1 AFTER capacity;

UPDATE rooms SET beds = 2 WHERE category_label LIKE 'เตียงคู่%';
UPDATE rooms SET beds = 1 WHERE category_label LIKE 'เตียงเดี่ยว%';

-- =========================================================
-- Migration: ตารางรีวิวจากผู้เข้าพัก
-- รันส่วนนี้ถ้าฐานข้อมูลถูกสร้างไปแล้วก่อนหน้านี้
-- =========================================================
CREATE TABLE IF NOT EXISTS reviews (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NOT NULL,
  content    TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
