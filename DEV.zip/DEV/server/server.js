require('dotenv').config();
require('express-async-errors');

const dns = require('dns');
dns.setServers(['8.8.8.8', '8.8.4.4']);

const express = require('express');
const cors = require('cors');
const session = require('express-session');
const MongoStore = require('connect-mongo');

const connectDB = require('./config/db');
const apiRoutes = require('./routes/api');

const app = express();

app.set('etag', false);

// =========================
// Environment
// =========================

const isProd = process.env.NODE_ENV === 'production';

// รองรับหลาย Origin คั่นด้วยลูกน้ำ
// เช่น:
// FRONTEND_ORIGIN=https://preferrent.github.io,https://www.preferrent.com
const allowedOrigins = (process.env.FRONTEND_ORIGIN || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);

// =========================
// CORS
// =========================

app.use(cors({
    origin: allowedOrigins.length ? allowedOrigins : true,
    credentials: true
}));

// =========================
// Body Parser
// =========================

app.use(express.json());

// =========================
// Session
// =========================

app.use(session({
    secret: process.env.SESSION_SECRET || 'change-me',
    resave: false,
    saveUninitialized: false,

    store: MongoStore.create({
        mongoUrl: process.env.MONGODB_URI
    }),

    cookie: {
        httpOnly: true,

        // Production = HTTPS
        secure: isProd,

        // ถ้า Frontend และ Backend อยู่คนละโดเมน
        sameSite: isProd ? 'none' : 'lax',

        maxAge: 1000 * 60 * 60 * 24 * 7
    }
}));

// =========================
// API Routes
// =========================

// คง /api ไว้เหมือนเดิม
// เช่น /api/rooms.php
// /api/login.php
// /api/bookings.php

app.use('/api', apiRoutes);

// =========================
// Health Check
// =========================

app.get('/', (req, res) => {
    res.json({
        ok: true,
        message: 'PreferRent API (Node.js + MongoDB) กำลังทำงาน',
        environment: process.env.NODE_ENV || 'development'
    });
});

// =========================
// Error Handler
// =========================

app.use((err, req, res, next) => {
    console.error(err);

    res.status(500).json({
        error: 'เกิดข้อผิดพลาดที่เซิร์ฟเวอร์'
    });
});

// =========================
// Start Server
// =========================

const PORT = process.env.PORT || 4000;

connectDB()
    .then(() => {

        // สำคัญสำหรับ Render / Cloud Hosting
        app.listen(PORT, '0.0.0.0', () => {
            console.log(`PreferRent API running on port ${PORT}`);
        });

    })
    .catch((err) => {
        console.error('ไม่สามารถเชื่อมต่อ MongoDB ได้:', err);
        process.exit(1);
    });